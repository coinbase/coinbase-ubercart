coinbase-ubercart
=================

Accept Bitcoin on your Ubercart-powered website with Coinbase. 

Download the plugin here: https://github.com/coinbase/coinbase-ubercart/archive/master.zip

Installation
-------

Download the plugin using the above link. Open the Drupal 'Modules' page and click 'Install new module'. Follow the steps to install the downloaded zip file. After installation, enable the module by clicking its checkbox on the Modules page. (the module is in the Ubercart - Payment section.)

After you've installed the plugin, click on Store > Configuration > Payment Methods.

![Step 1](http://i.imgur.com/huIdH69.png)

If you don't have a Coinbase account, sign up at https://coinbase.com/merchants. Coinbase offers daily payouts for merchants in the United States. For more infomation on setting up payouts, see https://coinbase.com/docs/merchant_tools/payouts.

To the right of 'Bitcoin (Coinbase)', click 'Settings', and follow the instructions to connect a merchant account.

![Step 2](http://i.imgur.com/z0dGjD4.png)
